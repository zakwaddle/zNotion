class NotionBase:
    pass